package Contact;

import java.util.ArrayList;

public class ContactService {
	public static ArrayList<Contact> contactList = new ArrayList<Contact>();
	public void displayContactList() {
		}
	}
	public static String generateUniqueId() {
		public addContact(Contact A) {
			contactExist = false;
			for (Contact 1:listContacts) {
				if (1.equals(A)) {
					ContactExist = true;
				}
		if(ContactExist) {
			listContacts.add(A);
			return true;
		}
		else {
			return false;
			
			}
		}
		Public deleteContact(String ContactID) {
			for(Cintact 1:listContacts) {
				if(1.getContactID().equals(ContactID)) {
					
				}
			}
	pulic updateContact(String Contactid,firstName,lastName, phoneNumber, address) {
		for(Contact :ContactList) {
			if (Contact.getID(.equals(id)){
				Contact.setfirstName(firstName);
				Contact.setLastName(lastName);
				Contact.setphoneNumber(phoneNumber);
				Contact.setAddress(Address);
				System.out.println("updated contact");
				return true;
			}
		}
		else
			return false;
	}
	
		