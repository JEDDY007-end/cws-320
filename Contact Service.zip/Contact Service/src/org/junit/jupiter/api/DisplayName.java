package org.junit.jupiter.api;

public @interface DisplayName {

}
