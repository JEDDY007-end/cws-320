package Contact;

public static void main(String[]args);

public class Contact {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	private String contactId;
	private String phone;
	

	
	// Class ojects 
		public Contact(String contactId, String firstName, String lastName, String phone, String address) {
			if (contactId == null || contactId.length() > 10) {
				throw new IllegalArgumentException("Invalid ID");
			}
			
			if (firstName == null || firstName.length() > 10) {
				throw new IllegalArgumentException("Invalid First Name");
			}
			
			if (lastName == null || lastName.length() > 10) {
				throw new IllegalArgumentException("Invalid Last Name");
			}
			
			if (phone == null || phone.length() != 10) {
				throw new IllegalArgumentException("Invalid Phone Number");
			}
			
			if (address == null || address.length() > 30) {
				throw new IllegalArgumentException("Invalid Address");
			}
			
			this.contactId = contactId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
			this.address = address;
		}
		
		
		public String getId() {
			return contactId;
		}
		public String getFirstName() {
			return firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public String getPhone() {
			return phone;
		}
		public String getAddress() {
			return address;
		}
		
		public void setFirstName(String fName) {
			if (fName == null || fName.length() > 10) {
				throw new IllegalArgumentException("Ivalid First Name");
			}
			this.firstName = fName;
		}
		public void setLastName(String lName) {
			if (lName == null || lName.length() > 10) {
				throw new IllegalArgumentException("Invalid Last Name");
			}
			this.lastName = lName;
		}
		public void setPhone(String newPhone) {
			if (newPhone == null || newPhone.length() != 10) {
				throw new IllegalArgumentException("Inavlid Phone Number");
			}
			this.phone = newPhone;
		}
		public void setAddress(String newAddress) {
			if (newAddress == null || newAddress.length() > 30) {
				throw new IllegalArgumentException("Invalid Address");
			}
			this.address = newAddress;
		}
	}
