package Test;
public class ContactServiceTest {
protected String contactId,firstName,lastName,phoneNumber,address;
	import org.junit.jupiter.api.Test;
	import org.junit.jupiter.api.TestMethodOrder;
	import java.util.ArrayList;
	import org.junit.jupiter.api.DisplayName;
	import Contact.Contact;
	import Contact.ContactService;
	import org.junit.jupiter.api.Order;
		
		
	
	@Test
	@DisplayName("Test to Update First Name.")
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.updateFirstName("first", "8");
		service.displayContactList();
		assertEquals("first", service.getContact("8").getFirstName(), "First name not updated.");
	}

	@Test
	@DisplayName("Test to Update Last Name.")
	void testUpdateLastName() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.updateLastName("firsts", "10");
		service.displayContactList();
		assertEquals("firsts", service.getContact("10").getLastName(), "Last name not updated.");
	}

	@Test
	@DisplayName("Test to update phone number.")
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.updateNumber("1234567891", "4");
		assertEquals("1234567891", service.getContact("4").getNumber(), "Phone not updated.");
	}

	@Test
	@DisplayName("Test to update address.")
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.updateAddress("555 Nowhere Ave", "17");
		service.displayContactList();
		assertEquals("753 Nowhere Ave", service.getContact("17").getAddress(), "Address not updated.");
	}

	@Test
	@DisplayName("Test that service correctly deletes contacts.")
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.deleteContact("18");
		ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
		service.displayContactList();
		assertEquals(service.contactList, contactListEmpty, "The contactnot deleted.");
	}

	@Test
	@DisplayName("Test that service can add a contact.")
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("first", "last", "1234567891", "123 look out lane");
		service.displayContactList();
		assertNotNull(service.getContact("0"), "Contact not added correctly.");
	}

}