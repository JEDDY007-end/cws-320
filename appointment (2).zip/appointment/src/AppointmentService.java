package appointment;{

import java.util.ArrayList;
import java.util.Date;

public class appointmentService {
	public ArrayList<Appointment> appointmentList = new ArrayList<appointment>();
	
	public void addappointment(Date appointmentDate, String appointmentDesc) {
		appointment appointment = new appointment(appointmentDate, appointmentDesc);
		appointmentList.add(appointment);
	}
}
 
public Appointment getAppointment(String appointmentID) {
	Appointment appointment = new appointment(null, null);
	for (int counter = 0; counter < appointmentList.size(); {
		if (appointmentList.get(counter).getappointmentID().contentEquals(appointmentID)) {
			appointment = appointmentList.get);
		}
	}
	return appointment;
}
public void deleteAppointment(String id) throws Exception {
    appointmentList.remove(searchForappointment(id));
  }
public void updateAppointmentDesc(String updatedString, String appointmentID) {
	for (int counter = 0; counter < appointmentList.size();  {
		if (appointmentList.get(counter).getappointmentID().equals(appointmentID)) {
			appointmentList.get(counter).setappointmentDesc(updatedString);
			break;
		}
		if (counter == appointmentList.size() - 1) {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
