package Appointment;

import java.util.Date;

public class Appointment {
	private final String appointmentID;
	private Date appointmentDate;
	private String appointmentDesc;
	
	public String getappointmentID() {
		return appointmentID;
	}
	
	public Date getappointmentDate() {
		return appointmentDate;
	}
	
	public String getappointmentDesc() {
		return appointmentDesc;
	}
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			appointmentDate = new Date();
		} else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Cannot make appointment.");
		} else {
			this.appointmentDate = appointmentDate;
		}
	}
	
	public void setAppointmentDesc(String appointmentDesc) {
		if (appointmentDesc == null || appointmentDesc.isEmpty()) {
			this.appointmentDesc = "NULL";
		} else if (appointmentDesc.length() > 50) {
			this.appointmentDesc = appointmentDesc.substring(0, 50);
		} else {
			this.appointmentDesc = appointmentDesc;
		}
	}
	
	public void updateAppointmentId(String id) {
	    if (id == null) {
	      throw new IllegalArgumentException("Appointment ID cannot be null.");
	    } else if (id.length() > APPOINTMENT_ID_LENGTH) {
	      throw new IllegalArgumentException("Appointment ID cannot exceed " +
	                                         APPOINTMENT_ID_LENGTH +
	                                         " characters.");
	    } else {
	      this.appointmentId = id;
	    }
	  }

}