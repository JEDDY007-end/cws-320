package appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

	  private String id, description;
	  private String tooLongId, tooLongDescription;
	  private Date date, pastDate;
  }
}
@Test
void setUp() {
    id = "1234567890";
    description = "The appt must have a required description.";
    date = new Date(2028, Calendar.February , 14);
    tooLongId = "123456789123456789123456789";
    tooLongDescription =
        "This description is too long,";
    pastDate = new Date(0);
 }
}
@Test
void testAppointmentDateBeforeCurrent() {
	Appointment appointment = new Appointment(Date(2028, Calendar.February, 14), "Description");
	if (appointment.getAppointmentDate().before(new Date())) {
		fail("Appointment Date is before current date.");
	}
}
@Test
void testAppointmentDateNotNull() {
	Appointment appointment = new Appointment(null, "Description");
	assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null.");
}

@Test
void testAppointmentDescNotNull() {
	Appointment task = new Appointment(Date(2028, Calendar.February, 14), null);
	assertNotNull(task.getAppointmentDesc(), "Appointment Description was null.");
}
}