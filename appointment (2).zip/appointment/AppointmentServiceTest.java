package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
  private String id, description, tooLongDescription;
  private Date date, pastDate;
 }
}
private Date Date(int i, int February, int f) {
	return null;
}

@Test
void testUpdateAppointmentDate() {
	AppointmentService service = new AppointmentService();
	service.addAppointment(Date(2024, Calendar.February, 14), "Description");
	service.updateAppointmentDate(Date(2028, Calendar.FEBRUARY, 14));
	service.displayAppointmentList();
	assertEquals(Date(2028, Calendar.FEBRUARY, 14), service.getAppointment().getAppointmentDate(), "Appointment date was not updated.");
}

@Test
void testUpdateAppointmentDesc() {
	AppointmentService service = new AppointmentService();
	service.addAppointment(Date(2028, Calendar.February, 14), "Description");
	service.updateAppointmentDesc("Updated Description");
	service.displayAppointmentList();
	assertEquals("Updated Description", service.getAppointment().getAppointmentDesc(), "Appointment description was not updated.");
}

@Test
void testDeleteAppointment() {
	AppointmentService service = new AppointmentService();
	service.addAppointment(Date(2024, Calendar.February, 1), "Description");
	service.deleteAppointment();
		ArrayList<Appointment> appointmentListEmpty = new ArrayList<Appointment>();
	service.displayAppointmentList();
	assertEquals(service.appointmentList, appointmentListEmpty, "The appointment not deleted.");
}

@Test
void testAddAppointment() {
	AppointmentService service = new AppointmentService();
	service.addAppointment(Date(2024, Calendar.February, 14), "Description");
	service.displayAppointmentList();
	assertNotNull(service.getAppointment(), "Appointmentnot added correctly.");